"use client"

import { useState } from "react"
import { SiteHeader } from "@/components/site-header"
import { LandingPage } from "@/components/landing-page"
import { ValidatorPage } from "@/components/validator-page"

export default function Home() {
  const [activeView, setActiveView] = useState<"landing" | "validator">(
    "landing"
  )

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader activeView={activeView} onNavigate={setActiveView} />
      <main>
        {activeView === "landing" ? (
          <LandingPage onGetStarted={() => setActiveView("validator")} />
        ) : (
          <ValidatorPage />
        )}
      </main>
    </div>
  )
}
