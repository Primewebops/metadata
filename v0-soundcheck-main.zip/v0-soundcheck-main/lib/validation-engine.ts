export interface TrackMetadata {
  id: string
  trackTitle: string
  artistName: string
  albumTitle: string
  releaseDate: string
  genre: string
  isrc: string
  copyright: string
  trackNumber: string
  duration: string
  label: string
  upc: string
  language: string
  explicit: string
  fileFormat: string
}

export interface ValidationIssue {
  field: keyof TrackMetadata
  severity: "error" | "warning" | "info"
  message: string
  suggestion?: string
}

export interface ValidationResult {
  track: TrackMetadata
  issues: ValidationIssue[]
  score: number
  status: "passed" | "warning" | "failed"
  optimizations: OptimizationTip[]
}

export interface OptimizationTip {
  field: keyof TrackMetadata
  tip: string
  impact: "high" | "medium" | "low"
}

const VALID_GENRES = [
  "Pop", "Rock", "Hip-Hop/Rap", "R&B/Soul", "Electronic", "Dance",
  "Country", "Jazz", "Classical", "Blues", "Reggae", "Latin",
  "Metal", "Punk", "Folk", "Indie", "Alternative", "World",
  "Gospel", "Funk", "Disco", "House", "Techno", "Drum & Bass",
  "Ambient", "New Age", "Soundtrack", "Spoken Word", "Comedy",
  "Children's", "K-Pop", "Afrobeats", "Trap", "Lo-Fi",
]

const VALID_LANGUAGES = [
  "English", "Spanish", "French", "German", "Portuguese", "Italian",
  "Japanese", "Korean", "Chinese", "Hindi", "Arabic", "Russian",
  "Dutch", "Swedish", "Norwegian", "Danish", "Finnish", "Polish",
  "Turkish", "Thai", "Indonesian", "Vietnamese", "Tagalog",
]

function validateISRC(isrc: string): boolean {
  // ISRC format: CC-XXX-YY-NNNNN (country code, registrant, year, designation)
  const isrcPattern = /^[A-Z]{2}-?[A-Z0-9]{3}-?\d{2}-?\d{5}$/
  return isrcPattern.test(isrc.toUpperCase().replace(/\s/g, ''))
}

function validateUPC(upc: string): boolean {
  // UPC/EAN: 12 or 13 digits
  const upcPattern = /^\d{12,13}$/
  return upcPattern.test(upc.replace(/\s/g, ''))
}

function validateDate(dateStr: string): boolean {
  const datePattern = /^\d{4}-\d{2}-\d{2}$/
  if (!datePattern.test(dateStr)) return false
  const date = new Date(dateStr)
  return !isNaN(date.getTime())
}

function checkTitleFormatting(title: string): ValidationIssue[] {
  const issues: ValidationIssue[] = []

  if (title !== title.trim()) {
    issues.push({
      field: "trackTitle",
      severity: "error",
      message: "Track title has leading or trailing whitespace.",
      suggestion: `Remove whitespace: "${title.trim()}"`,
    })
  }

  if (/\s{2,}/.test(title)) {
    issues.push({
      field: "trackTitle",
      severity: "warning",
      message: "Track title contains multiple consecutive spaces.",
      suggestion: `Clean up: "${title.replace(/\s{2,}/g, ' ')}"`,
    })
  }

  if (title === title.toUpperCase() && title.length > 3) {
    issues.push({
      field: "trackTitle",
      severity: "warning",
      message: "Track title is in ALL CAPS, which may reduce discoverability.",
      suggestion: "Use title case instead for better streaming platform presentation.",
    })
  }

  if (title === title.toLowerCase()) {
    issues.push({
      field: "trackTitle",
      severity: "info",
      message: "Track title is in all lowercase.",
      suggestion: "Consider using title case for a more professional appearance.",
    })
  }

  if (/[^\w\s\-'&().,!?/:"']/.test(title)) {
    issues.push({
      field: "trackTitle",
      severity: "warning",
      message: "Track title contains unusual special characters.",
      suggestion: "Remove special characters that may not display correctly on all platforms.",
    })
  }

  // Check for version info that should be in parentheses
  const versionKeywords = ["remix", "edit", "version", "mix", "remaster", "live", "acoustic", "demo", "instrumental"]
  for (const keyword of versionKeywords) {
    const regex = new RegExp(`\\b${keyword}\\b`, 'i')
    if (regex.test(title) && !title.includes('(') && !title.includes('[')) {
      issues.push({
        field: "trackTitle",
        severity: "warning",
        message: `Version/remix info "${keyword}" should be in parentheses per industry standards.`,
        suggestion: `Move version info to parentheses, e.g., "Track Name (${keyword.charAt(0).toUpperCase() + keyword.slice(1)})"`,
      })
    }
  }

  return issues
}

function checkArtistName(name: string): ValidationIssue[] {
  const issues: ValidationIssue[] = []

  if (!name.trim()) {
    issues.push({
      field: "artistName",
      severity: "error",
      message: "Artist name is required.",
    })
    return issues
  }

  if (name !== name.trim()) {
    issues.push({
      field: "artistName",
      severity: "error",
      message: "Artist name has leading or trailing whitespace.",
      suggestion: `Remove whitespace: "${name.trim()}"`,
    })
  }

  if (name === name.toUpperCase() && name.length > 3) {
    issues.push({
      field: "artistName",
      severity: "warning",
      message: "Artist name is in ALL CAPS.",
      suggestion: "Use proper casing for better presentation on streaming platforms.",
    })
  }

  // Check for "feat." format
  if (/\bfeat\.?\b/i.test(name) || /\bft\.?\b/i.test(name)) {
    issues.push({
      field: "artistName",
      severity: "warning",
      message: "Featured artists should be listed separately, not in the artist name field.",
      suggestion: 'Use the track title field for featured artists, e.g., "Song Title (feat. Artist)".',
    })
  }

  // Check for "Various Artists" misuse
  if (/various\s+artists?/i.test(name)) {
    issues.push({
      field: "artistName",
      severity: "info",
      message: '"Various Artists" should only be used for compilation albums.',
    })
  }

  return issues
}

export function validateTrack(track: TrackMetadata): ValidationResult {
  const issues: ValidationIssue[] = []
  const optimizations: OptimizationTip[] = []

  // Required field checks
  if (!track.trackTitle.trim()) {
    issues.push({ field: "trackTitle", severity: "error", message: "Track title is required." })
  } else {
    issues.push(...checkTitleFormatting(track.trackTitle))
  }

  issues.push(...checkArtistName(track.artistName))

  if (!track.albumTitle.trim()) {
    issues.push({ field: "albumTitle", severity: "error", message: "Album title is required." })
  }

  // Release date validation
  if (!track.releaseDate.trim()) {
    issues.push({ field: "releaseDate", severity: "error", message: "Release date is required." })
  } else if (!validateDate(track.releaseDate)) {
    issues.push({
      field: "releaseDate",
      severity: "error",
      message: "Invalid date format. Use YYYY-MM-DD.",
      suggestion: "Example: 2025-06-15",
    })
  } else {
    const releaseDate = new Date(track.releaseDate)
    const now = new Date()
    if (releaseDate < new Date('1900-01-01')) {
      issues.push({
        field: "releaseDate",
        severity: "error",
        message: "Release date is unrealistically old.",
      })
    }
    if (releaseDate > new Date(now.getFullYear() + 2, 11, 31)) {
      issues.push({
        field: "releaseDate",
        severity: "warning",
        message: "Release date is more than 2 years in the future.",
      })
    }
  }

  // Genre validation
  if (!track.genre.trim()) {
    issues.push({ field: "genre", severity: "error", message: "Genre is required." })
  } else {
    const matchedGenre = VALID_GENRES.find(g => g.toLowerCase() === track.genre.toLowerCase())
    if (!matchedGenre) {
      const closestMatch = VALID_GENRES.find(g =>
        g.toLowerCase().includes(track.genre.toLowerCase()) ||
        track.genre.toLowerCase().includes(g.toLowerCase())
      )
      issues.push({
        field: "genre",
        severity: "warning",
        message: `"${track.genre}" is not a standard genre classification.`,
        suggestion: closestMatch
          ? `Did you mean "${closestMatch}"?`
          : `Choose from standard genres: ${VALID_GENRES.slice(0, 5).join(', ')}...`,
      })
    }
  }

  // ISRC validation
  if (!track.isrc.trim()) {
    issues.push({ field: "isrc", severity: "error", message: "ISRC code is required for distribution." })
  } else if (!validateISRC(track.isrc)) {
    issues.push({
      field: "isrc",
      severity: "error",
      message: "Invalid ISRC format.",
      suggestion: "ISRC format should be: CC-XXX-YY-NNNNN (e.g., US-S1Z-03-00001)",
    })
  }

  // Copyright validation
  if (!track.copyright.trim()) {
    issues.push({ field: "copyright", severity: "error", message: "Copyright information is required." })
  } else {
    if (!/\d{4}/.test(track.copyright)) {
      issues.push({
        field: "copyright",
        severity: "warning",
        message: "Copyright notice should include a year.",
        suggestion: `Example: "${new Date().getFullYear()} Your Label Name"`,
      })
    }
    if (!/[©℗]/.test(track.copyright) && !/\(c\)/i.test(track.copyright) && !/\(p\)/i.test(track.copyright)) {
      issues.push({
        field: "copyright",
        severity: "info",
        message: 'Consider including the copyright symbol (©) or phonogram symbol (℗).',
        suggestion: `Example: "© ${new Date().getFullYear()} Label Name" or "℗ ${new Date().getFullYear()} Label Name"`,
      })
    }
  }

  // Track number validation
  if (track.trackNumber.trim()) {
    const num = parseInt(track.trackNumber)
    if (isNaN(num) || num < 1) {
      issues.push({
        field: "trackNumber",
        severity: "error",
        message: "Track number must be a positive integer.",
      })
    }
    if (num > 99) {
      issues.push({
        field: "trackNumber",
        severity: "warning",
        message: "Track number exceeds 99, which is unusual.",
      })
    }
  }

  // UPC validation
  if (track.upc.trim() && !validateUPC(track.upc)) {
    issues.push({
      field: "upc",
      severity: "error",
      message: "Invalid UPC/EAN format. Must be 12 or 13 digits.",
      suggestion: "Example: 012345678901",
    })
  }

  // Language validation
  if (track.language.trim()) {
    const matchedLang = VALID_LANGUAGES.find(l => l.toLowerCase() === track.language.toLowerCase())
    if (!matchedLang) {
      issues.push({
        field: "language",
        severity: "warning",
        message: `"${track.language}" may not be a recognized language.`,
        suggestion: `Standard options include: ${VALID_LANGUAGES.slice(0, 5).join(', ')}...`,
      })
    }
  }

  // Explicit flag validation
  if (track.explicit.trim() && !["true", "false", "clean", "explicit"].includes(track.explicit.toLowerCase())) {
    issues.push({
      field: "explicit",
      severity: "warning",
      message: 'Explicit flag should be "true", "false", "clean", or "explicit".',
    })
  }

  // File format validation - WAV only
  if (!track.fileFormat.trim()) {
    issues.push({
      field: "fileFormat",
      severity: "error",
      message: "File format is required. Only WAV files are accepted for distribution.",
      suggestion: "Select WAV as the file format.",
    })
  } else if (track.fileFormat.toLowerCase() !== "wav") {
    issues.push({
      field: "fileFormat",
      severity: "error",
      message: `"${track.fileFormat}" is not an accepted file format. Only WAV files are allowed.`,
      suggestion: "Convert your audio file to WAV format (16-bit or 24-bit, 44.1kHz or higher) before submitting.",
    })
  }

  // Optimization tips
  if (track.trackTitle.trim() && track.trackTitle.length < 3) {
    optimizations.push({
      field: "trackTitle",
      tip: "Very short titles may hurt discoverability. Consider a more descriptive title.",
      impact: "medium",
    })
  }

  if (track.trackTitle.trim() && track.trackTitle.length > 100) {
    optimizations.push({
      field: "trackTitle",
      tip: "Very long titles may be truncated on some platforms. Keep it under 100 characters.",
      impact: "medium",
    })
  }

  if (track.genre.trim()) {
    const trendingGenres = ["K-Pop", "Afrobeats", "Lo-Fi", "Latin", "Indie"]
    if (trendingGenres.some(g => g.toLowerCase() === track.genre.toLowerCase())) {
      optimizations.push({
        field: "genre",
        tip: `"${track.genre}" is a trending genre! Ensure your tags and descriptions match for better algorithmic placement.`,
        impact: "high",
      })
    }
  }

  if (!track.language.trim()) {
    optimizations.push({
      field: "language",
      tip: "Adding a language tag helps streaming platforms recommend your music to the right audience.",
      impact: "high",
    })
  }

  if (!track.label.trim()) {
    optimizations.push({
      field: "label",
      tip: "Adding a label name improves professionalism and searchability.",
      impact: "low",
    })
  }

  if (track.explicit.trim() === "") {
    optimizations.push({
      field: "explicit",
      tip: "Setting the explicit flag helps platforms apply correct parental controls and filters.",
      impact: "medium",
    })
  }

  if (track.fileFormat.toLowerCase() === "wav") {
    optimizations.push({
      field: "fileFormat",
      tip: "WAV is the gold standard for distribution. Ensure your file is 16-bit or 24-bit at 44.1kHz or higher for best quality.",
      impact: "high",
    })
  }

  // Calculate score
  const errors = issues.filter(i => i.severity === "error").length
  const warnings = issues.filter(i => i.severity === "warning").length
  const maxScore = 100
  const score = Math.max(0, maxScore - errors * 15 - warnings * 5)

  let status: "passed" | "warning" | "failed" = "passed"
  if (errors > 0) status = "failed"
  else if (warnings > 0) status = "warning"

  return { track, issues, score, status, optimizations }
}

export function detectDuplicates(tracks: TrackMetadata[]): { indices: [number, number]; reason: string }[] {
  const duplicates: { indices: [number, number]; reason: string }[] = []

  for (let i = 0; i < tracks.length; i++) {
    for (let j = i + 1; j < tracks.length; j++) {
      const a = tracks[i]
      const b = tracks[j]

      // Exact ISRC match
      if (a.isrc && b.isrc && a.isrc.toUpperCase().replace(/[-\s]/g, '') === b.isrc.toUpperCase().replace(/[-\s]/g, '')) {
        duplicates.push({
          indices: [i, j],
          reason: `Duplicate ISRC code: ${a.isrc}`,
        })
      }

      // Same title + artist
      if (
        a.trackTitle.toLowerCase().trim() === b.trackTitle.toLowerCase().trim() &&
        a.artistName.toLowerCase().trim() === b.artistName.toLowerCase().trim() &&
        a.trackTitle.trim() && a.artistName.trim()
      ) {
        duplicates.push({
          indices: [i, j],
          reason: `Same track title "${a.trackTitle}" by "${a.artistName}"`,
        })
      }
    }
  }

  return duplicates
}

export function parseCSV(csvText: string): TrackMetadata[] {
  const lines = csvText.split('\n').filter(line => line.trim())
  if (lines.length < 2) return []

  const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/[\s_]+/g, ''))
  const tracks: TrackMetadata[] = []

  const headerMap: Record<string, keyof TrackMetadata> = {
    tracktitle: "trackTitle",
    title: "trackTitle",
    track: "trackTitle",
    song: "trackTitle",
    songname: "trackTitle",
    artistname: "artistName",
    artist: "artistName",
    albumtitle: "albumTitle",
    album: "albumTitle",
    releasedate: "releaseDate",
    date: "releaseDate",
    release: "releaseDate",
    genre: "genre",
    isrc: "isrc",
    isrccode: "isrc",
    copyright: "copyright",
    tracknumber: "trackNumber",
    trackno: "trackNumber",
    number: "trackNumber",
    "#": "trackNumber",
    duration: "duration",
    length: "duration",
    label: "label",
    recordlabel: "label",
    upc: "upc",
    ean: "upc",
    upcean: "upc",
    language: "language",
    lang: "language",
    explicit: "explicit",
    fileformat: "fileFormat",
    format: "fileFormat",
    audioformat: "fileFormat",
    filetype: "fileFormat",
  }

  for (let i = 1; i < lines.length; i++) {
    // Simple CSV parse (handles basic cases)
    const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''))

    const track: TrackMetadata = {
      id: `track-${i}`,
      trackTitle: "",
      artistName: "",
      albumTitle: "",
      releaseDate: "",
      genre: "",
      isrc: "",
      copyright: "",
      trackNumber: "",
      duration: "",
      label: "",
      upc: "",
      language: "",
      explicit: "",
      fileFormat: "",
    }

    headers.forEach((header, idx) => {
      const key = headerMap[header]
      if (key && idx < values.length) {
        track[key] = values[idx] || ""
      }
    })

    tracks.push(track)
  }

  return tracks
}

export const VALID_GENRES_LIST = VALID_GENRES
export const VALID_LANGUAGES_LIST = VALID_LANGUAGES
