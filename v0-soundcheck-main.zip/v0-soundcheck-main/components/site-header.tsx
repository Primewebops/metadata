"use client"

import { useState } from "react"
import { Music2, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SiteHeaderProps {
  activeView: "landing" | "validator"
  onNavigate: (view: "landing" | "validator") => void
}

export function SiteHeader({ activeView, onNavigate }: SiteHeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 lg:px-8">
        <button
          onClick={() => onNavigate("landing")}
          className="flex items-center gap-2.5 transition-opacity hover:opacity-80"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Music2 className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-lg font-semibold tracking-tight text-foreground">
            SoundCheck
          </span>
        </button>

        <nav className="hidden items-center gap-1 md:flex">
          <button
            onClick={() => onNavigate("landing")}
            className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeView === "landing"
                ? "text-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onNavigate("validator")}
            className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
              activeView === "validator"
                ? "text-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Validator
          </button>
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <Button
            variant="default"
            size="sm"
            onClick={() => onNavigate("validator")}
          >
            Start Validating
          </Button>
        </div>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="flex h-9 w-9 items-center justify-center rounded-md text-muted-foreground transition-colors hover:text-foreground md:hidden"
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-border bg-background px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-2">
            <button
              onClick={() => {
                onNavigate("landing")
                setMobileOpen(false)
              }}
              className="rounded-md px-3 py-2 text-left text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              Home
            </button>
            <button
              onClick={() => {
                onNavigate("validator")
                setMobileOpen(false)
              }}
              className="rounded-md px-3 py-2 text-left text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              Validator
            </button>
            <Button
              variant="default"
              size="sm"
              className="mt-2"
              onClick={() => {
                onNavigate("validator")
                setMobileOpen(false)
              }}
            >
              Start Validating
            </Button>
          </nav>
        </div>
      )}
    </header>
  )
}
