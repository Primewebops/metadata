"use client"

import {
  CheckCircle2,
  ArrowRight,
  Shield,
  Zap,
  FileSearch,
  BarChart3,
  Upload,
  Sparkles,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface LandingPageProps {
  onGetStarted: () => void
}

const features = [
  {
    icon: FileSearch,
    title: "Deep Metadata Scanning",
    description:
      "Validate track titles, artist names, album info, release dates, genres, ISRC codes, and copyright details against industry standards.",
  },
  {
    icon: Shield,
    title: "Error Detection",
    description:
      "Identify inconsistencies, missing required fields, formatting errors, and potential duplicates before they cause distribution issues.",
  },
  {
    icon: Upload,
    title: "Bulk Validation",
    description:
      "Upload entire catalogs via CSV and validate hundreds of tracks at once. Perfect for labels managing large libraries.",
  },
  {
    icon: Sparkles,
    title: "Optimization Tips",
    description:
      "Get actionable recommendations to improve metadata for better discoverability on Spotify, Apple Music, and other platforms.",
  },
  {
    icon: Zap,
    title: "Instant Feedback",
    description:
      "Real-time validation with clear pass/warning/fail indicators and specific suggestions for every issue found.",
  },
  {
    icon: BarChart3,
    title: "Distribution Ready",
    description:
      "Ensure only properly validated metadata proceeds to release. Prevent costly rejections from distributors and platforms.",
  },
]

const stats = [
  { value: "15+", label: "Fields Validated" },
  { value: "50+", label: "Rules Applied" },
  { value: "99.9%", label: "Accuracy Rate" },
  { value: "0.5s", label: "Avg. Scan Time" },
]

export function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="relative">
      {/* Hero */}
      <section className="relative overflow-hidden py-24 lg:py-36">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute left-1/2 top-0 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-primary/20 blur-[120px]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-1.5 text-sm text-muted-foreground">
              <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
              Industry-standard metadata validation
            </div>
            <h1 className="text-balance text-5xl font-bold tracking-tight text-foreground lg:text-7xl">
              Validate your music metadata{" "}
              <span className="text-primary">before release</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground lg:text-xl">
              Catch errors, fix inconsistencies, and optimize metadata for
              streaming platforms. Stop distribution rejections before they
              happen.
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button size="lg" onClick={onGetStarted} className="gap-2 px-8">
                Start Validating
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={onGetStarted}
                className="gap-2 border-border text-foreground hover:bg-secondary"
              >
                <Upload className="h-4 w-4" />
                Upload Catalog
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-border bg-secondary/30 py-12">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 md:grid-cols-4 lg:px-8">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl font-bold text-primary lg:text-4xl">
                {stat.value}
              </div>
              <div className="mt-1 text-sm text-muted-foreground">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mx-auto mb-16 max-w-2xl text-center">
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground lg:text-4xl">
              Everything you need for clean metadata
            </h2>
            <p className="mt-4 text-pretty text-muted-foreground">
              Comprehensive validation that covers every field your distributor
              and streaming platforms require.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="group rounded-xl border border-border bg-card p-6 transition-colors hover:border-primary/30 hover:bg-card/80"
              >
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <feature.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="mb-2 text-lg font-semibold text-card-foreground">
                  {feature.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="border-t border-border bg-secondary/20 py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mx-auto mb-16 max-w-2xl text-center">
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground lg:text-4xl">
              How it works
            </h2>
            <p className="mt-4 text-pretty text-muted-foreground">
              Three simple steps to distribution-ready metadata.
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                step: "01",
                title: "Enter or Upload",
                description:
                  "Input a single track or upload a CSV of your entire catalog. We support all standard metadata fields.",
              },
              {
                step: "02",
                title: "Review Results",
                description:
                  "Get instant validation with color-coded severity levels, specific error messages, and fix suggestions.",
              },
              {
                step: "03",
                title: "Fix & Distribute",
                description:
                  "Apply recommended fixes, optimize for discoverability, and confidently submit for distribution.",
              },
            ].map((item) => (
              <div key={item.step} className="relative">
                <div className="mb-4 text-5xl font-bold text-primary/20">
                  {item.step}
                </div>
                <h3 className="mb-2 text-xl font-semibold text-foreground">
                  {item.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 lg:px-8">
          <div className="mx-auto max-w-2xl rounded-2xl border border-border bg-card p-8 text-center lg:p-12">
            <h2 className="text-balance text-3xl font-bold text-card-foreground">
              Ready to validate your catalog?
            </h2>
            <p className="mt-4 text-pretty text-muted-foreground">
              Start checking your metadata now. No signup required.
            </p>
            <Button
              size="lg"
              onClick={onGetStarted}
              className="mt-8 gap-2 px-8"
            >
              Launch Validator
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="mx-auto max-w-7xl px-4 text-center text-sm text-muted-foreground lg:px-8">
          SoundCheck Metadata Validator. Built for artists, labels, and
          distributors.
        </div>
      </footer>
    </div>
  )
}
