"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Music2, Upload } from "lucide-react"
import { SingleTrackForm } from "@/components/single-track-form"
import { BulkUpload } from "@/components/bulk-upload"
import { ValidationResults } from "@/components/validation-results"
import type { ValidationResult } from "@/lib/validation-engine"

type ViewState =
  | { type: "form" }
  | {
      type: "results"
      results: ValidationResult[]
      duplicates?: { indices: [number, number]; reason: string }[]
    }

export function ValidatorPage() {
  const [view, setView] = useState<ViewState>({ type: "form" })
  const [activeTab, setActiveTab] = useState("single")

  const handleSingleResult = (result: ValidationResult) => {
    setView({ type: "results", results: [result] })
  }

  const handleBulkResults = (
    results: ValidationResult[],
    duplicates: { indices: [number, number]; reason: string }[]
  ) => {
    setView({ type: "results", results, duplicates })
  }

  const handleBack = () => {
    setView({ type: "form" })
  }

  if (view.type === "results") {
    return (
      <div className="mx-auto max-w-5xl px-4 py-8 lg:px-8">
        <ValidationResults
          results={view.results}
          duplicates={view.duplicates}
          onBack={handleBack}
        />
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">
          Metadata Validator
        </h1>
        <p className="mt-2 text-muted-foreground">
          Check your music metadata against industry standards before submitting
          for distribution.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6 bg-secondary">
          <TabsTrigger
            value="single"
            className="gap-1.5 data-[state=active]:bg-card data-[state=active]:text-foreground"
          >
            <Music2 className="h-3.5 w-3.5" />
            Single Track
          </TabsTrigger>
          <TabsTrigger
            value="bulk"
            className="gap-1.5 data-[state=active]:bg-card data-[state=active]:text-foreground"
          >
            <Upload className="h-3.5 w-3.5" />
            Bulk Upload
          </TabsTrigger>
        </TabsList>

        <TabsContent value="single">
          <SingleTrackForm onValidationComplete={handleSingleResult} />
        </TabsContent>

        <TabsContent value="bulk">
          <BulkUpload onBulkValidationComplete={handleBulkResults} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
