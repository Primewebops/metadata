"use client"

import { useState } from "react"
import {
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Info,
  ChevronDown,
  ChevronRight,
  ArrowLeft,
  Copy,
  Lightbulb,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import type { ValidationResult } from "@/lib/validation-engine"
import { toast } from "sonner"

interface ValidationResultsProps {
  results: ValidationResult[]
  duplicates?: { indices: [number, number]; reason: string }[]
  onBack: () => void
}

function ScoreBadge({ score, status }: { score: number; status: string }) {
  const colorClass =
    status === "passed"
      ? "bg-success/15 text-success border-success/30"
      : status === "warning"
        ? "bg-warning/15 text-warning border-warning/30"
        : "bg-destructive/15 text-destructive border-destructive/30"

  return (
    <span
      className={`inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-bold ${colorClass}`}
    >
      {score}/100
    </span>
  )
}

function StatusIcon({ status }: { status: string }) {
  if (status === "passed") return <CheckCircle2 className="h-5 w-5 text-success" />
  if (status === "warning") return <AlertTriangle className="h-5 w-5 text-warning" />
  return <XCircle className="h-5 w-5 text-destructive" />
}

function SeverityIcon({ severity }: { severity: string }) {
  if (severity === "error") return <XCircle className="h-3.5 w-3.5 text-destructive" />
  if (severity === "warning") return <AlertTriangle className="h-3.5 w-3.5 text-warning" />
  return <Info className="h-3.5 w-3.5 text-primary" />
}

function ImpactBadge({ impact }: { impact: string }) {
  const classes =
    impact === "high"
      ? "bg-primary/15 text-primary border-primary/30"
      : impact === "medium"
        ? "bg-warning/15 text-warning border-warning/30"
        : "bg-muted text-muted-foreground border-border"

  return (
    <span className={`inline-flex items-center rounded border px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wider ${classes}`}>
      {impact}
    </span>
  )
}

function SingleResult({
  result,
  index,
  defaultOpen,
}: {
  result: ValidationResult
  index: number
  defaultOpen: boolean
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen)
  const errors = result.issues.filter((i) => i.severity === "error")
  const warnings = result.issues.filter((i) => i.severity === "warning")
  const infos = result.issues.filter((i) => i.severity === "info")

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden">
      {/* Header */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex w-full items-center gap-4 px-5 py-4 text-left transition-colors hover:bg-secondary/30"
        aria-expanded={isOpen}
      >
        <StatusIcon status={result.status} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-card-foreground truncate">
              {result.track.trackTitle || "Untitled Track"}
            </span>
            {result.track.artistName && (
              <span className="text-xs text-muted-foreground truncate">
                by {result.track.artistName}
              </span>
            )}
          </div>
          <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
            {errors.length > 0 && (
              <span className="flex items-center gap-1 text-destructive">
                <XCircle className="h-3 w-3" /> {errors.length} error{errors.length !== 1 ? "s" : ""}
              </span>
            )}
            {warnings.length > 0 && (
              <span className="flex items-center gap-1 text-warning">
                <AlertTriangle className="h-3 w-3" /> {warnings.length} warning{warnings.length !== 1 ? "s" : ""}
              </span>
            )}
            {infos.length > 0 && (
              <span className="flex items-center gap-1 text-primary">
                <Info className="h-3 w-3" /> {infos.length} tip{infos.length !== 1 ? "s" : ""}
              </span>
            )}
            {result.issues.length === 0 && (
              <span className="text-success">All checks passed</span>
            )}
          </div>
        </div>
        <ScoreBadge score={result.score} status={result.status} />
        {isOpen ? (
          <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
        ) : (
          <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
        )}
      </button>

      {/* Body */}
      {isOpen && (
        <div className="border-t border-border px-5 py-4 space-y-4">
          {/* Issues */}
          {result.issues.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Issues Found
              </h4>
              <div className="space-y-2">
                {result.issues.map((issue, i) => (
                  <div
                    key={`${issue.field}-${i}`}
                    className="flex gap-3 rounded-lg bg-secondary/50 p-3"
                  >
                    <SeverityIcon severity={issue.severity} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge
                          variant="outline"
                          className="text-[10px] font-mono border-border text-muted-foreground"
                        >
                          {issue.field}
                        </Badge>
                        <span
                          className={`text-[10px] font-medium uppercase tracking-wider ${
                            issue.severity === "error"
                              ? "text-destructive"
                              : issue.severity === "warning"
                                ? "text-warning"
                                : "text-primary"
                          }`}
                        >
                          {issue.severity}
                        </span>
                      </div>
                      <p className="mt-1 text-sm text-card-foreground">
                        {issue.message}
                      </p>
                      {issue.suggestion && (
                        <div className="mt-1.5 flex items-start gap-1.5">
                          <Lightbulb className="mt-0.5 h-3 w-3 shrink-0 text-primary" />
                          <p className="text-xs text-muted-foreground">
                            {issue.suggestion}
                          </p>
                        </div>
                      )}
                    </div>
                    {issue.suggestion && (
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(issue.suggestion || "")
                          toast.success("Suggestion copied to clipboard")
                        }}
                        className="shrink-0 text-muted-foreground transition-colors hover:text-foreground"
                        title="Copy suggestion"
                        aria-label="Copy suggestion"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Optimization Tips */}
          {result.optimizations.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Optimization Recommendations
              </h4>
              <div className="space-y-2">
                {result.optimizations.map((opt, i) => (
                  <div
                    key={`opt-${i}`}
                    className="flex items-start gap-3 rounded-lg bg-primary/5 border border-primary/10 p-3"
                  >
                    <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className="text-[10px] font-mono border-border text-muted-foreground"
                        >
                          {opt.field}
                        </Badge>
                        <ImpactBadge impact={opt.impact} />
                      </div>
                      <p className="mt-1 text-sm text-card-foreground">
                        {opt.tip}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Metadata summary */}
          <div className="space-y-2">
            <h4 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Metadata Summary
            </h4>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {(
                [
                  ["Track Title", result.track.trackTitle],
                  ["Artist", result.track.artistName],
                  ["Album", result.track.albumTitle],
                  ["Release Date", result.track.releaseDate],
                  ["Genre", result.track.genre],
                  ["ISRC", result.track.isrc],
                  ["Copyright", result.track.copyright],
                  ["Track #", result.track.trackNumber],
                  ["Label", result.track.label],
                  ["UPC", result.track.upc],
                  ["Language", result.track.language],
                  ["Explicit", result.track.explicit],
                  ["File Format", result.track.fileFormat],
                ] as const
              )
                .filter(([, val]) => val)
                .map(([label, val]) => (
                  <div
                    key={label}
                    className="flex items-center justify-between rounded-md bg-secondary/50 px-3 py-2"
                  >
                    <span className="text-xs text-muted-foreground">
                      {label}
                    </span>
                    <span className="max-w-[60%] truncate text-xs font-medium text-card-foreground">
                      {val}
                    </span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export function ValidationResults({
  results,
  duplicates = [],
  onBack,
}: ValidationResultsProps) {
  const [filter, setFilter] = useState<"all" | "passed" | "warning" | "failed">(
    "all"
  )

  const passed = results.filter((r) => r.status === "passed").length
  const warned = results.filter((r) => r.status === "warning").length
  const failed = results.filter((r) => r.status === "failed").length
  const avgScore = results.length
    ? Math.round(results.reduce((s, r) => s + r.score, 0) / results.length)
    : 0
  const totalIssues = results.reduce((s, r) => s + r.issues.length, 0)

  const filtered =
    filter === "all" ? results : results.filter((r) => r.status === filter)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            Back
          </Button>
          <div>
            <h2 className="text-xl font-semibold text-foreground">
              Validation Results
            </h2>
            <p className="text-sm text-muted-foreground">
              {results.length} track{results.length !== 1 ? "s" : ""} scanned
              {" | "}
              {totalIssues} issue{totalIssues !== 1 ? "s" : ""} found
            </p>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="text-xs text-muted-foreground">Average Score</div>
          <div className="mt-1 flex items-end gap-2">
            <span className="text-3xl font-bold text-foreground">{avgScore}</span>
            <span className="mb-1 text-sm text-muted-foreground">/100</span>
          </div>
          <Progress
            value={avgScore}
            className="mt-3 h-1.5 bg-secondary"
          />
        </div>
        <button
          onClick={() => setFilter(filter === "passed" ? "all" : "passed")}
          className={`rounded-xl border p-4 text-left transition-colors ${
            filter === "passed" ? "border-success/50 bg-success/5" : "border-border bg-card"
          }`}
        >
          <div className="text-xs text-muted-foreground">Passed</div>
          <div className="mt-1 flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-success" />
            <span className="text-3xl font-bold text-success">{passed}</span>
          </div>
        </button>
        <button
          onClick={() => setFilter(filter === "warning" ? "all" : "warning")}
          className={`rounded-xl border p-4 text-left transition-colors ${
            filter === "warning" ? "border-warning/50 bg-warning/5" : "border-border bg-card"
          }`}
        >
          <div className="text-xs text-muted-foreground">Warnings</div>
          <div className="mt-1 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            <span className="text-3xl font-bold text-warning">{warned}</span>
          </div>
        </button>
        <button
          onClick={() => setFilter(filter === "failed" ? "all" : "failed")}
          className={`rounded-xl border p-4 text-left transition-colors ${
            filter === "failed" ? "border-destructive/50 bg-destructive/5" : "border-border bg-card"
          }`}
        >
          <div className="text-xs text-muted-foreground">Failed</div>
          <div className="mt-1 flex items-center gap-2">
            <XCircle className="h-5 w-5 text-destructive" />
            <span className="text-3xl font-bold text-destructive">{failed}</span>
          </div>
        </button>
      </div>

      {/* Duplicates */}
      {duplicates.length > 0 && (
        <div className="rounded-xl border border-warning/30 bg-warning/5 p-4 space-y-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-warning" />
            <h3 className="text-sm font-semibold text-warning">
              Potential Duplicates Detected
            </h3>
          </div>
          {duplicates.map((dup, i) => (
            <div
              key={i}
              className="flex items-center gap-2 rounded-lg bg-secondary/50 px-3 py-2 text-sm text-card-foreground"
            >
              <span className="font-mono text-xs text-muted-foreground">
                Track {dup.indices[0] + 1} & Track {dup.indices[1] + 1}
              </span>
              <span className="text-muted-foreground">{" | "}</span>
              <span>{dup.reason}</span>
            </div>
          ))}
        </div>
      )}

      {/* Results list */}
      <div className="space-y-3">
        {filtered.map((result, i) => (
          <SingleResult
            key={result.track.id + i}
            result={result}
            index={i}
            defaultOpen={results.length === 1}
          />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="py-12 text-center text-muted-foreground">
          No tracks match the selected filter.
        </div>
      )}
    </div>
  )
}
