"use client"

import { useState, useCallback, useRef } from "react"
import {
  Upload,
  FileText,
  AlertCircle,
  Download,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  type TrackMetadata,
  type ValidationResult,
  parseCSV,
  validateTrack,
  detectDuplicates,
} from "@/lib/validation-engine"

interface BulkUploadProps {
  onBulkValidationComplete: (
    results: ValidationResult[],
    duplicates: { indices: [number, number]; reason: string }[]
  ) => void
}

const sampleCSV = `Track Title,Artist Name,Album Title,Release Date,Genre,ISRC,Copyright,Track Number,Duration,Label,UPC,Language,Explicit,File Format
Midnight Dreams,Luna Rivera,Echoes of Tomorrow,2026-07-15,Electronic,US-S1Z-26-00042,© 2026 Stellar Records,1,4:12,Stellar Records,012345678901,English,false,WAV
Sunset Boulevard,The Neon Lights,City After Dark,2026-08-01,Pop,US-S1Z-26-00043,© 2026 Stellar Records,2,3:45,Stellar Records,012345678901,English,false,WAV
BROKEN HEARTS CLUB,  jake smith  ,broken hearts ep,2026-06-20,rnb,INVALID-ISRC,2026 No Label,1,,,,MP3
Starlight (feat. Maya),DJ COSMOS,Space Odyssey,2026/13/45,Electronica,US-S1Z-26-00045,,3,5:20,Cosmos Music,0123456789,Spanish,maybe,FLAC
Midnight Dreams,Luna Rivera,Different Album,2026-09-01,Pop,US-S1Z-26-00042,© 2026 Stellar Records,1,3:30,Stellar Records,012345678902,English,false,WAV
Ocean Waves,Aria Chen,Tidal Patterns,2026-10-15,Ambient,,© 2026 Deep Blue Records,4,7:22,Deep Blue Records,012345678903,Japanese,false,WAV
Running Wild,,Freedom,2026-11-01,Rock,US-S1Z-26-00047,2026 Rock Label,1,4:01,Rock Label,,English,explicit,`

export function BulkUpload({ onBulkValidationComplete }: BulkUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [fileName, setFileName] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [parsedTracks, setParsedTracks] = useState<TrackMetadata[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const processFile = useCallback((file: File) => {
    setError(null)

    if (!file.name.endsWith(".csv") && !file.name.endsWith(".txt")) {
      setError("Please upload a CSV file.")
      return
    }

    if (file.size > 10 * 1024 * 1024) {
      setError("File size exceeds 10MB limit.")
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      const text = e.target?.result as string
      const tracks = parseCSV(text)

      if (tracks.length === 0) {
        setError(
          "No valid tracks found. Ensure your CSV has headers and at least one data row."
        )
        return
      }

      setFileName(file.name)
      setParsedTracks(tracks)
    }
    reader.onerror = () => setError("Failed to read file.")
    reader.readAsText(file)
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback(() => {
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      const file = e.dataTransfer.files[0]
      if (file) processFile(file)
    },
    [processFile]
  )

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) processFile(file)
    },
    [processFile]
  )

  const handleValidateAll = () => {
    const results = parsedTracks.map((t) => validateTrack(t))
    const duplicates = detectDuplicates(parsedTracks)
    onBulkValidationComplete(results, duplicates)
  }

  const handleClear = () => {
    setFileName(null)
    setParsedTracks([])
    setError(null)
    if (fileInputRef.current) fileInputRef.current.value = ""
  }

  const handleDownloadSample = () => {
    const blob = new Blob([sampleCSV], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "sample-metadata.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleLoadSample = () => {
    const tracks = parseCSV(sampleCSV)
    setFileName("sample-metadata.csv")
    setParsedTracks(tracks)
    setError(null)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">
            Bulk Catalog Validation
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Upload a CSV file with your catalog metadata. We support standard
            column headers.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleLoadSample}
            className="gap-1.5 border-border text-foreground hover:bg-secondary"
          >
            Load Sample
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadSample}
            className="gap-1.5 border-border text-foreground hover:bg-secondary"
          >
            <Download className="h-3.5 w-3.5" />
            CSV Template
          </Button>
        </div>
      </div>

      {/* Drop zone */}
      {parsedTracks.length === 0 ? (
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative flex min-h-[240px] cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed transition-colors ${
            isDragging
              ? "border-primary bg-primary/5"
              : "border-border hover:border-muted-foreground/50"
          }`}
          onClick={() => fileInputRef.current?.click()}
          role="button"
          tabIndex={0}
          aria-label="Upload CSV file"
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") fileInputRef.current?.click()
          }}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.txt"
            onChange={handleFileInput}
            className="hidden"
            aria-hidden="true"
          />
          <Upload className="mb-4 h-10 w-10 text-muted-foreground" />
          <p className="text-sm font-medium text-foreground">
            Drop your CSV file here or click to browse
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Supports CSV files up to 10MB
          </p>
        </div>
      ) : (
        <div className="rounded-xl border border-border bg-card p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <FileText className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-card-foreground">
                  {fileName}
                </p>
                <p className="text-xs text-muted-foreground">
                  {parsedTracks.length} track
                  {parsedTracks.length !== 1 ? "s" : ""} detected
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClear}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Preview table */}
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm" role="table">
              <thead>
                <tr className="border-b border-border">
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground">
                    #
                  </th>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground">
                    Title
                  </th>
                  <th className="px-3 py-2 text-left font-medium text-muted-foreground">
                    Artist
                  </th>
                  <th className="hidden px-3 py-2 text-left font-medium text-muted-foreground md:table-cell">
                    Album
                  </th>
                  <th className="hidden px-3 py-2 text-left font-medium text-muted-foreground lg:table-cell">
                    ISRC
                  </th>
                </tr>
              </thead>
              <tbody>
                {parsedTracks.slice(0, 10).map((t, i) => (
                  <tr
                    key={t.id}
                    className="border-b border-border/50 last:border-0"
                  >
                    <td className="px-3 py-2 text-muted-foreground">{i + 1}</td>
                    <td className="max-w-[200px] truncate px-3 py-2 text-card-foreground">
                      {t.trackTitle || <span className="text-destructive">Missing</span>}
                    </td>
                    <td className="max-w-[160px] truncate px-3 py-2 text-card-foreground">
                      {t.artistName || <span className="text-destructive">Missing</span>}
                    </td>
                    <td className="hidden max-w-[160px] truncate px-3 py-2 text-card-foreground md:table-cell">
                      {t.albumTitle || <span className="text-destructive">Missing</span>}
                    </td>
                    <td className="hidden px-3 py-2 font-mono text-xs text-muted-foreground lg:table-cell">
                      {t.isrc || <span className="text-destructive">Missing</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {parsedTracks.length > 10 && (
              <p className="mt-2 text-center text-xs text-muted-foreground">
                ...and {parsedTracks.length - 10} more track
                {parsedTracks.length - 10 !== 1 ? "s" : ""}
              </p>
            )}
          </div>

          <div className="mt-6 flex justify-end">
            <Button size="lg" onClick={handleValidateAll} className="gap-2 px-8">
              Validate {parsedTracks.length} Track
              {parsedTracks.length !== 1 ? "s" : ""}
            </Button>
          </div>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      {/* Supported columns */}
      <div className="rounded-lg border border-border bg-card/50 p-4">
        <p className="mb-2 text-xs font-medium text-muted-foreground">
          Supported CSV columns:
        </p>
        <div className="flex flex-wrap gap-1.5">
          {[
            "Track Title",
            "Artist Name",
            "Album Title",
            "Release Date",
            "Genre",
            "ISRC",
            "Copyright",
            "Track Number",
            "Duration",
            "Label",
            "UPC/EAN",
            "Language",
            "Explicit",
            "File Format",
          ].map((col) => (
            <span
              key={col}
              className="rounded-md bg-secondary px-2 py-0.5 text-xs text-secondary-foreground"
            >
              {col}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
