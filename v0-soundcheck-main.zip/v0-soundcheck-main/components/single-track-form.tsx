"use client"

import { useState } from "react"
import {
  Music2,
  User,
  Disc3,
  Calendar,
  Tag,
  Hash,
  Copyright,
  Clock,
  Building2,
  Barcode,
  Globe,
  AlertTriangle,
  FileAudio,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  type TrackMetadata,
  type ValidationResult,
  validateTrack,
  VALID_GENRES_LIST,
  VALID_LANGUAGES_LIST,
} from "@/lib/validation-engine"

interface SingleTrackFormProps {
  onValidationComplete: (result: ValidationResult) => void
}

const emptyTrack: TrackMetadata = {
  id: "single-track",
  trackTitle: "",
  artistName: "",
  albumTitle: "",
  releaseDate: "",
  genre: "",
  isrc: "",
  copyright: "",
  trackNumber: "",
  duration: "",
  label: "",
  upc: "",
  language: "",
  explicit: "",
  fileFormat: "",
}

interface FieldConfig {
  key: keyof TrackMetadata
  label: string
  icon: React.ComponentType<{ className?: string }>
  placeholder: string
  required: boolean
  type?: "text" | "date" | "select-genre" | "select-language" | "select-explicit" | "select-format"
}

const fields: FieldConfig[] = [
  {
    key: "trackTitle",
    label: "Track Title",
    icon: Music2,
    placeholder: "Enter track title",
    required: true,
  },
  {
    key: "artistName",
    label: "Artist Name",
    icon: User,
    placeholder: "Enter artist name",
    required: true,
  },
  {
    key: "albumTitle",
    label: "Album Title",
    icon: Disc3,
    placeholder: "Enter album title",
    required: true,
  },
  {
    key: "releaseDate",
    label: "Release Date",
    icon: Calendar,
    placeholder: "YYYY-MM-DD",
    required: true,
    type: "date",
  },
  {
    key: "genre",
    label: "Genre",
    icon: Tag,
    placeholder: "Select genre",
    required: true,
    type: "select-genre",
  },
  {
    key: "isrc",
    label: "ISRC Code",
    icon: Hash,
    placeholder: "US-S1Z-03-00001",
    required: true,
  },
  {
    key: "copyright",
    label: "Copyright",
    icon: Copyright,
    placeholder: "© 2026 Label Name",
    required: true,
  },
  {
    key: "trackNumber",
    label: "Track Number",
    icon: Hash,
    placeholder: "1",
    required: false,
  },
  {
    key: "duration",
    label: "Duration",
    icon: Clock,
    placeholder: "3:45",
    required: false,
  },
  {
    key: "label",
    label: "Record Label",
    icon: Building2,
    placeholder: "Enter label name",
    required: false,
  },
  {
    key: "upc",
    label: "UPC/EAN",
    icon: Barcode,
    placeholder: "012345678901",
    required: false,
  },
  {
    key: "language",
    label: "Language",
    icon: Globe,
    placeholder: "Select language",
    required: false,
    type: "select-language",
  },
  {
    key: "explicit",
    label: "Explicit Content",
    icon: AlertTriangle,
    placeholder: "Select",
    required: false,
    type: "select-explicit",
  },
  {
    key: "fileFormat",
    label: "File Format",
    icon: FileAudio,
    placeholder: "Select file format",
    required: true,
    type: "select-format",
  },
]

export function SingleTrackForm({ onValidationComplete }: SingleTrackFormProps) {
  const [track, setTrack] = useState<TrackMetadata>({ ...emptyTrack })

  const updateField = (key: keyof TrackMetadata, value: string) => {
    setTrack((prev) => ({ ...prev, [key]: value }))
  }

  const handleValidate = () => {
    const result = validateTrack(track)
    onValidationComplete(result)
  }

  const handleClear = () => {
    setTrack({ ...emptyTrack })
  }

  const handleLoadSample = () => {
    setTrack({
      id: "single-track",
      trackTitle: "Midnight Dreams (Remix)",
      artistName: "Luna Rivera",
      albumTitle: "Echoes of Tomorrow",
      releaseDate: "2026-07-15",
      genre: "Electronic",
      isrc: "US-S1Z-26-00042",
      copyright: "\u00A9 2026 Stellar Records",
      trackNumber: "3",
      duration: "4:12",
      label: "Stellar Records",
      upc: "012345678901",
      language: "English",
      explicit: "false",
      fileFormat: "WAV",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold text-foreground">
            Single Track Validation
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Fill in your track metadata below. Required fields are marked with
            an asterisk.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleLoadSample} className="border-border text-foreground hover:bg-secondary">
            Load Sample
          </Button>
          <Button variant="outline" size="sm" onClick={handleClear} className="border-border text-foreground hover:bg-secondary">
            Clear
          </Button>
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {fields.map((field) => (
          <div key={field.key} className="space-y-2">
            <Label
              htmlFor={field.key}
              className="flex items-center gap-1.5 text-sm font-medium text-foreground"
            >
              <field.icon className="h-3.5 w-3.5 text-muted-foreground" />
              {field.label}
              {field.required && (
                <span className="text-destructive">*</span>
              )}
            </Label>

            {field.type === "select-genre" ? (
              <Select
                value={track[field.key]}
                onValueChange={(val) => updateField(field.key, val)}
              >
                <SelectTrigger
                  id={field.key}
                  className="w-full bg-secondary border-border text-foreground"
                >
                  <SelectValue placeholder={field.placeholder} />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {VALID_GENRES_LIST.map((genre) => (
                    <SelectItem key={genre} value={genre}>
                      {genre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : field.type === "select-language" ? (
              <Select
                value={track[field.key]}
                onValueChange={(val) => updateField(field.key, val)}
              >
                <SelectTrigger
                  id={field.key}
                  className="w-full bg-secondary border-border text-foreground"
                >
                  <SelectValue placeholder={field.placeholder} />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  {VALID_LANGUAGES_LIST.map((lang) => (
                    <SelectItem key={lang} value={lang}>
                      {lang}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : field.type === "select-explicit" ? (
              <Select
                value={track[field.key]}
                onValueChange={(val) => updateField(field.key, val)}
              >
                <SelectTrigger
                  id={field.key}
                  className="w-full bg-secondary border-border text-foreground"
                >
                  <SelectValue placeholder={field.placeholder} />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  <SelectItem value="false">Clean</SelectItem>
                  <SelectItem value="true">Explicit</SelectItem>
                </SelectContent>
              </Select>
            ) : field.type === "select-format" ? (
              <Select
                value={track[field.key]}
                onValueChange={(val) => updateField(field.key, val)}
              >
                <SelectTrigger
                  id={field.key}
                  className="w-full bg-secondary border-border text-foreground"
                >
                  <SelectValue placeholder={field.placeholder} />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  <SelectItem value="WAV">WAV (Required)</SelectItem>
                  <SelectItem value="MP3" disabled>
                    MP3 (Not Accepted)
                  </SelectItem>
                  <SelectItem value="FLAC" disabled>
                    FLAC (Not Accepted)
                  </SelectItem>
                  <SelectItem value="AAC" disabled>
                    AAC (Not Accepted)
                  </SelectItem>
                  <SelectItem value="OGG" disabled>
                    OGG (Not Accepted)
                  </SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <Input
                id={field.key}
                type={field.type === "date" ? "date" : "text"}
                placeholder={field.placeholder}
                value={track[field.key]}
                onChange={(e) => updateField(field.key, e.target.value)}
                className="bg-secondary border-border text-foreground placeholder:text-muted-foreground"
              />
            )}
          </div>
        ))}
      </div>

      <div className="flex justify-end pt-2">
        <Button size="lg" onClick={handleValidate} className="gap-2 px-8">
          Validate Track
          <Hash className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
